def append_row(data):
    # Implementation of append_row
    pass
